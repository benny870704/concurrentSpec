import sys
import os.path

HERE0 = os.path.dirname(__file__) or os.curdir
os.chdir(HERE0)
HERE = os.curdir
sys.path.insert(0, HERE)

from setuptools import setup, find_packages

# -----------------------------------------------------------------
# CONFIGURATIONS:
# -----------------------------------------------------------------
python_version = float("%s.%s" % sys.version_info[:2])
CONCURRENTSPEC = os.path.join(HERE, "concurrentSpec")
# README = os.path.join(CONCURRENTSPEC, "README.md")
# long_description = "".join(open(README).readlines())
long_description = ""

# -----------------------------------------------------------------
# UTILITIES:
# -----------------------------------------------------------------
def find_packages_by_root_package(where):
    """
    Better than excluding everything that is not needed,
    collect only what is needed.
    """
    root_package = os.path.basename(where)
    packages = [ "%s.%s" % (root_package, sub_package)
                 for sub_package in find_packages(where)]
    packages.insert(0, root_package)
    return packages

setup(
    name = 'concurrentSpec',
    version = '1.0.0-b1',
    description = 'A behavior-driven development tool using Python',
    long_description=long_description,
    author = 'Kun-Che Li, Bing-Yun Wang, Che-Hung Tsai',
    author_email = ['milkkuan@gmail.com', 'benny870704@gmail.com', 'tsai880806@gmail.com'],
    url = 'https://github.com/benny870704/concurrentSpec_research',
    packages=find_packages_by_root_package(CONCURRENTSPEC),
    data_files=[('/concurrentSpec/src/reporter/', ['concurrentSpec/src/reporter/test_result_html.css', 'concurrentSpec/src/reporter/test_result_template.html'])],
    entry_points = {
        "console_scripts": [
            "concurrentSpec = concurrentSpec.src.main:main"
        ]
    },
    license='MIT',
)